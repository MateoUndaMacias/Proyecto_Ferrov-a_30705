package controlador;

import java.util.List;
import modelo.ConexionBD;
import modelo.Reserva;
import modelo.ReservaDAO;
import util.NotificadorCambios;
import util.ObservadorCambios;

public class ReservaControlador {
private final ReservaDAO dao = new ReservaDAO();

public boolean cambiarEstadoReserva(String idReserva, String nuevoEstado) {
    try {
        // Ejemplo de actualización en MongoDB usando el ID y el nuevo estado ("RESERVADO" o "CANCELADO")
        org.bson.types.ObjectId objectId = new org.bson.types.ObjectId(idReserva);
        com.mongodb.client.MongoCollection<org.bson.Document> coleccion = ConexionBD.getConexion().getCollection("reservas");
        
        coleccion.updateOne(
            com.mongodb.client.model.Filters.eq("_id", objectId), 
            com.mongodb.client.model.Updates.set("estado", nuevoEstado)
        );
        return true;
    } catch (Exception e) {
        System.out.println("Error al cambiar estado: " + e.getMessage());
        return false;
    }
}

    public List<Reserva> historial(String username) {
        if (username == null || username.trim().isEmpty()) throw new IllegalArgumentException("El username es obligatorio");
        return dao.listarPorUsuario(username);
    }

    public boolean cancelar(String idReserva) {
        if (idReserva == null) return false;
        boolean ok = dao.cancelarReserva(idReserva);
        if (ok) NotificadorCambios.getInstancia().notificar(ObservadorCambios.TIPO_RESERVA);
        return ok;
    }

    public List<Reserva> listarReservas() { return dao.listarReservas(); }

public boolean crearReserva(modelo.Reserva reserva) {
    if (reserva == null) return false;
    
    // Asegurar el estado inicial
    reserva.setEstado("RESERVADO"); 

    // Guardar a través del DAO
    boolean insertado = dao.guardar(reserva);

    if (insertado) {
        util.NotificadorCambios.getInstancia().notificar(util.ObservadorCambios.TIPO_RESERVA);
    }

    return insertado;
}}
