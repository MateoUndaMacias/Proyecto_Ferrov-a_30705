package controlador;

import java.util.List;
import modelo.Reserva;
import modelo.Tren;
import modelo.Usuario;

// Patrón Facade: Oculta la complejidad de los subsistemas (Controladores) a la Vista.
public class SistemaFacade {
    
    private static SistemaFacade instancia;
    
    private final UsuarioControlador usuarioControl;
    private final ReservaControlador reservaControl;
    private final TrenControlador trenControl;

    private SistemaFacade() {
        this.usuarioControl = new UsuarioControlador();
        this.reservaControl = new ReservaControlador();
        this.trenControl = new TrenControlador();
    }

    public static SistemaFacade getInstancia() {
        if (instancia == null) {
            instancia = new SistemaFacade();
        }
        return instancia;
    }

    public Usuario login(String username, String password) { 
        return usuarioControl.iniciarSesion(username, password); 
    }
    
    public boolean registrarUsuario(Usuario u) { 
        return usuarioControl.registrarUsuario(u); 
    }
    
    public List<Reserva> obtenerReservas(boolean esAdmin, String username) {
        return esAdmin ? reservaControl.listarReservas() : reservaControl.historial(username);
    }
    
    public boolean cancelarReserva(String idReserva) { 
        return reservaControl.cancelar(idReserva); 
    }
    
    public boolean crearReserva(Reserva reserva) { 
        return reservaControl.crearReserva(reserva); 
    }
    
    // AQUÍ ESTABA EL ERROR: El método en TrenControlador se llama filtrarTrenes
    public List<Tren> buscarTrenes(String criterio) { 
        return trenControl.filtrarTrenes(criterio); 
    }
    
    public boolean registrarTren(Tren tren) { 
        return trenControl.registrarTren(tren); 
    }
}