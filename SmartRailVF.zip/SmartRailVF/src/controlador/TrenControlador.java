package controlador;

import java.util.List;
import modelo.Tren;
import modelo.TrenDAO;
import util.NotificadorCambios;
import util.ObservadorCambios;

public class TrenControlador {
    private final TrenDAO trenDAO;

    public TrenControlador() { this.trenDAO = new TrenDAO(); }

    public List<Tren> listarTrenes() { return trenDAO.listarTrenes(); }

    public List<Tren> filtrarTrenes(String criterio) {
        if (criterio == null || criterio.trim().isEmpty()) return trenDAO.listarTrenes();
        return trenDAO.buscarTrenesPorCriterio(criterio.trim());
    }

    public boolean registrarTren(Tren tren) {
        boolean ok = trenDAO.insertar(tren);
        if (ok) NotificadorCambios.getInstancia().notificar(ObservadorCambios.TIPO_TREN);
        return ok;
    }

    public boolean eliminarTren(String codigo) {
        boolean ok = trenDAO.eliminarTren(codigo);
        if (ok) NotificadorCambios.getInstancia().notificar(ObservadorCambios.TIPO_TREN);
        return ok;
    }

    public boolean cambiarEstado(String codigo, boolean activo) {
        boolean ok = trenDAO.cambiarEstado(codigo, activo);
        if (ok) NotificadorCambios.getInstancia().notificar(ObservadorCambios.TIPO_TREN);
        return ok;
    }

    public boolean actualizarTren(String codigo, String ruta, int capacidad, double precio, boolean activo) {
        if (codigo == null || codigo.trim().isEmpty() || ruta == null || ruta.trim().isEmpty() || capacidad <= 0 || precio <= 0) return false;
        boolean ok = trenDAO.actualizarTren(codigo, ruta, capacidad, precio, activo);
        if (ok) NotificadorCambios.getInstancia().notificar(ObservadorCambios.TIPO_TREN);
        return ok;
    }}
