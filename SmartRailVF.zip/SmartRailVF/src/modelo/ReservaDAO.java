package modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;

public class ReservaDAO {
    private MongoCollection<Document> reservasCol;
    private MongoCollection<Document> horariosCol;

    public ReservaDAO() {
        MongoDatabase db = ConexionBD.getConexion();
        if (db != null) {
            reservasCol = db.getCollection("reservas");
            horariosCol = db.getCollection("horarios");
        }
    }

    // Clean Code: Recibe el modelo Reserva, no un Document
    public boolean guardar(Reserva reserva) {
        if (reservasCol == null || reserva == null) return false;
        
        Document doc = new Document("username", reserva.getUsername())
                .append("tren", reserva.getTren())
                .append("fecha", reserva.getFecha())
                .append("idHorario", reserva.getIdHorario())
                .append("monto", reserva.getMonto())
                .append("estado", reserva.getEstado());
                
        reservasCol.insertOne(doc);
        return true;
    }

    public boolean cancelarReserva(String idReserva) {
        if (reservasCol == null || idReserva == null) return false;
        try {
            org.bson.types.ObjectId oid = new org.bson.types.ObjectId(idReserva);
            Document res = reservasCol.find(eq("_id", oid)).first();
            if (res == null || !"RESERVADO".equalsIgnoreCase(res.getString("estado"))) return false;
            
            reservasCol.updateOne(eq("_id", oid), new Document("$set", new Document("estado", "CANCELADO")));
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    public List<Reserva> listarPorUsuario(String username) {
        List<Reserva> lista = new ArrayList<>();
        if (reservasCol != null && username != null && !username.trim().isEmpty()) {
            for (Document rDoc : reservasCol.find(eq("username", username))) {
                lista.add(construirReservaCompleta(rDoc));
            }
        }
        return lista;
    }

    public List<Reserva> listarReservas() {
        List<Reserva> lista = new ArrayList<>();
        if (reservasCol != null) {
            for (Document rDoc : reservasCol.find()) {
                lista.add(construirReservaCompleta(rDoc));
            }
        }
        return lista;
    }

    private Reserva construirReservaCompleta(Document rDoc) {
        Reserva r = new Reserva();
        if (rDoc.getObjectId("_id") != null) r.setId(rDoc.getObjectId("_id").toHexString());
        r.setUsername(rDoc.getString("username"));
        r.setTren(rDoc.getString("tren"));
        r.setFecha(rDoc.getString("fecha"));
        r.setIdHorario(rDoc.getString("idHorario"));
        r.setEstado(rDoc.getString("estado"));

        Document hDoc = null;
        String idHorario = r.getIdHorario();
        if (idHorario != null && idHorario.trim().length() == 24) {
            try { hDoc = horariosCol.find(eq("_id", new org.bson.types.ObjectId(idHorario.trim()))).first(); } 
            catch (IllegalArgumentException ignored) {}
        }
        
        if (hDoc == null) hDoc = horariosCol.find(and(eq("codigoTren", r.getTren()), eq("fecha", r.getFecha()))).first();

        if (hDoc != null) {
            r.setHoraSalida(hDoc.getString("horaSalida"));
            r.setHoraLlegada(hDoc.getString("horaLlegada"));
        } else {
            r.setHoraSalida("-");
            r.setHoraLlegada("-");
        }

        Object montoReserva = rDoc.get("monto");
        r.setMonto(montoReserva instanceof Number ? ((Number) montoReserva).doubleValue() : 0.0);
        return r;
    }
}