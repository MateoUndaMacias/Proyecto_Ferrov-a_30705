package modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.or;
import static com.mongodb.client.model.Filters.regex;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.conversions.Bson;

public class TrenDAO {
    private static final String COL_TRENES = "trenes";
    private MongoCollection<Document> coleccion;

    public TrenDAO() {
        MongoDatabase db = ConexionBD.getConexion();
        if (db != null) {
            coleccion = db.getCollection(COL_TRENES);
        }
    }

    public boolean insertar(Tren tren) {
        if (coleccion == null || tren == null) return false;
        try {
            if (obtenerTrenPorCodigo(tren.getCodigo()) != null) return false;
            
            Document doc = new Document("codigo", tren.getCodigo())
                    .append("ruta", tren.getRuta())
                    .append("capacidad", tren.getCapacidad())
                    .append("precio", tren.getPrecio())
                    .append("activo", tren.isActivo());
            coleccion.insertOne(doc);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Tren obtenerTrenPorCodigo(String codigo) {
        if (coleccion == null || codigo == null || codigo.trim().isEmpty()) return null;
        Document doc = coleccion.find(eq("codigo", codigo.trim())).first();
        return mapear(doc);
    }

    public List<Tren> listarTrenes() {
        List<Tren> lista = new ArrayList<>();
        if (coleccion != null) {
            for (Document doc : coleccion.find()) {
                lista.add(mapear(doc));
            }
        }
        return lista;
    }

    public List<Tren> buscarTrenesPorCriterio(String filtro) {
        List<Tren> lista = new ArrayList<>();
        if (coleccion == null) return lista;
        Bson query = (filtro == null || filtro.trim().isEmpty()) ? new Document() 
                   : or(regex("codigo", filtro.trim(), "i"), regex("ruta", filtro.trim(), "i"));
        
        for (Document doc : coleccion.find(query)) {
            lista.add(mapear(doc));
        }
        return lista;
    }

    public boolean eliminarTren(String codigo) {
        if (coleccion == null || codigo == null) return false;
        return coleccion.deleteOne(eq("codigo", codigo)).getDeletedCount() > 0;
    }

    public boolean cambiarEstado(String codigo, boolean activo) {
        if (coleccion == null || codigo == null) return false;
        coleccion.updateOne(eq("codigo", codigo), new Document("$set", new Document("activo", activo)));
        return true;
    }

    public boolean actualizarTren(String codigo, String ruta, int capacidad, double precio, boolean activo) {
        if (coleccion == null || codigo == null || codigo.trim().isEmpty()) return false;
        Document datos = new Document("ruta", ruta).append("capacidad", capacidad).append("precio", precio).append("activo", activo);
        coleccion.updateOne(eq("codigo", codigo), new Document("$set", datos));
        return true;
    }

    // Centralizamos el mapeo para evitar duplicar código (DRY)
    private Tren mapear(Document doc) {
        if (doc == null) return null;
        Tren t = new Tren();
        if (doc.getObjectId("_id") != null) t.setId(doc.getObjectId("_id").toHexString());
        t.setCodigo(doc.getString("codigo"));
        t.setRuta(doc.getString("ruta"));
        t.setCapacidad(doc.getInteger("capacidad", 0));
        t.setActivo(doc.getBoolean("activo", true));
        Object precioObj = doc.get("precio");
        t.setPrecio(precioObj instanceof Number ? ((Number) precioObj).doubleValue() : 0.0);
        return t;
    }
}