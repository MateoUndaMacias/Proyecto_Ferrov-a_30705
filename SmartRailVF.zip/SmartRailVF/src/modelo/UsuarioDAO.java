package modelo;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import java.util.ArrayList;
import java.util.List;

// ¡EL SECRETO ESTÁ AQUÍ! La importación correcta del Document de MongoDB
import org.bson.Document;
import org.bson.types.ObjectId;

public class UsuarioDAO {
    
    // Clean Code: Centralizamos los nombres de los campos en constantes (evita "Magic Strings" y errores de tipeo)
    private static final String COL_USUARIOS = "usuarios";
    private static final String CAMPO_NOMBRE = "nombre";
    private static final String CAMPO_USERNAME = "username";
    private static final String CAMPO_PASSWORD = "password";
    private static final String CAMPO_ROL = "rol";
    private static final String CAMPO_ACTIVO = "activo";

    private MongoCollection<Document> coleccion;

    public UsuarioDAO() {
        MongoDatabase db = ConexionBD.getConexion();
        if (db != null) {
            coleccion = db.getCollection(COL_USUARIOS);
        }
    }

    public Usuario login(String username, String password) {
        if (coleccion == null || username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return null;
        }

        Document doc = coleccion.find(and(
                eq(CAMPO_USERNAME, username.trim()),
                eq(CAMPO_ACTIVO, true)
        )).first();

        if (doc != null) {
            String passAlmacenado = doc.getString(CAMPO_PASSWORD);
            if (password.equals(passAlmacenado)) {
                return mapearDocumentoAUsuario(doc);
            }
        }
        return null;
    }

    public boolean registrar(Usuario u) {
        if (coleccion == null || u == null || u.getUsername() == null || u.getUsername().trim().isEmpty() || u.getPassword() == null || u.getPassword().trim().isEmpty()) {
            return false;
        }

        // Regla de Negocio: Validar que no exista el username previamente
        if (coleccion.find(eq(CAMPO_USERNAME, u.getUsername().trim())).first() != null) {
            return false;
        }

        try {
            // Clean Code: Mapeo limpio usando constantes
            Document doc = new Document(CAMPO_NOMBRE, u.getNombre())
                    .append(CAMPO_USERNAME, u.getUsername().trim())
                    .append(CAMPO_PASSWORD, u.getPassword())
                    .append(CAMPO_ROL, u.getRol())
                    .append(CAMPO_ACTIVO, true);

            coleccion.insertOne(doc);
            return true;
        } catch (Exception e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }

    public List<Usuario> listarUsuarios() {
        List<Usuario> lista = new ArrayList<>();
        if (coleccion != null) {
            for (Document doc : coleccion.find()) {
                lista.add(mapearDocumentoAUsuario(doc));
            }
        }
        return lista;
    }

    // Clean Code: Método privado (DRY) para encapsular la lógica repetitiva de mapear la BDD al POJO
    private Usuario mapearDocumentoAUsuario(Document doc) {
        if (doc == null) return null;

        Usuario u = new Usuario();
        ObjectId id = doc.getObjectId("_id");
        if (id != null) {
            u.setId(id.toHexString());
        }

        u.setNombre(doc.getString(CAMPO_NOMBRE));
        u.setUsername(doc.getString(CAMPO_USERNAME));
        u.setRol(doc.getString(CAMPO_ROL));
        
        // Manejo seguro de booleanos que podrían ser nulos en registros antiguos
        Boolean activo = doc.getBoolean(CAMPO_ACTIVO);
        u.setActivo(activo != null ? activo : true);

        return u;
    }
}