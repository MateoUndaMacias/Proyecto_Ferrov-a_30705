package vista;

import controlador.ReservaControlador;
import controlador.TrenControlador;
import controlador.UsuarioControlador;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.FileOutputStream;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import modelo.Reserva;
import modelo.Tren;
import modelo.Usuario;

// Importaciones de iText para la exportación a PDF
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PnlReporte extends javax.swing.JPanel {

    private JComboBox<String> cboTipoReporte;
    private JButton btnGenerar;
    private JButton btnPdf;
    private JButton btnImprimirDirecto;
    private JTable jTable1;

    public PnlReporte() {
        initComponentsPersonalizado();

        // Control de seguridad por roles
        if (!modelo.ControlSesion.getUsuario().getRol().equalsIgnoreCase("ADMIN")) {
            JOptionPane.showMessageDialog(this, "Acceso restringido a Administradores.", "Seguridad", JOptionPane.WARNING_MESSAGE);
            btnGenerar.setEnabled(false);
            btnPdf.setEnabled(false);
            btnImprimirDirecto.setEnabled(false);
        }
    }

    private void initComponentsPersonalizado() {
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Panel Superior (Título y Controles)
        JPanel pnlTop = new JPanel();
        pnlTop.setLayout(new BoxLayout(pnlTop, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel("Módulo de Reportes");
        lblTitulo.setFont(lblTitulo.getFont().deriveFont(Font.BOLD, 18f));
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel pnlControles = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        pnlControles.setAlignmentX(Component.LEFT_ALIGNMENT);

        pnlControles.add(new JLabel("Tipo de Reporte:"));
        
        // Opciones del menú (Sin pagos)
        cboTipoReporte = new JComboBox<>(new String[] { "Reservas", "Trenes", "Usuarios" });
        pnlControles.add(cboTipoReporte);

        // 1. Botón Generar Datos
        btnGenerar = new JButton("Generar Datos");
        btnGenerar.addActionListener(e -> btnGenerarActionPerformed(e));
        pnlControles.add(btnGenerar);

        // 2. Botón Exportar a PDF
        btnPdf = new JButton("Exportar a PDF");
        btnPdf.setBackground(new Color(52, 152, 219)); // Azul
        btnPdf.setForeground(Color.WHITE);
        btnPdf.addActionListener(e -> btnPdfActionPerformed(e));
        pnlControles.add(btnPdf);

        pnlTop.add(lblTitulo);
        pnlTop.add(Box.createVerticalStrut(10));
        pnlTop.add(pnlControles);

        add(pnlTop, BorderLayout.NORTH);

        // Panel Central (Tabla)
        jTable1 = new JTable();
        jTable1.setRowHeight(28);
        add(new JScrollPane(jTable1), BorderLayout.CENTER);
    }

    private void btnGenerarActionPerformed(java.awt.event.ActionEvent evt) {
        String tipo = cboTipoReporte.getSelectedItem().toString().trim();
        switch (tipo) {
            case "Reservas": cargarReporteReservas(); break;
            case "Trenes": cargarReporteTrenes(); break;
            case "Usuarios": cargarReporteUsuarios(); break;
        }
    }

    private void btnPdfActionPerformed(java.awt.event.ActionEvent evt) {
        if (jTable1.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay datos generados para exportar a PDF.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();
        fileChooser.setDialogTitle("Guardar Reporte PDF");
        if (fileChooser.showSaveDialog(this) == javax.swing.JFileChooser.APPROVE_OPTION) {
            String ruta = fileChooser.getSelectedFile().getAbsolutePath();
            if (!ruta.toLowerCase().endsWith(".pdf")) ruta += ".pdf";

            try {
                Document doc = new Document();
                PdfWriter.getInstance(doc, new FileOutputStream(ruta));
                doc.open();

                com.itextpdf.text.Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
                doc.add(new Paragraph("SmartRail - Reporte de " + cboTipoReporte.getSelectedItem(), fontTitulo));
                doc.add(new Paragraph(" ")); 

                PdfPTable pdfTable = new PdfPTable(jTable1.getColumnCount());
                pdfTable.setWidthPercentage(100);

                for (int i = 0; i < jTable1.getColumnCount(); i++) {
                    PdfPCell celda = new PdfPCell(new com.itextpdf.text.Phrase(jTable1.getColumnName(i)));
                    celda.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    pdfTable.addCell(celda);
                }

                for (int rows = 0; rows < jTable1.getRowCount(); rows++) {
                    for (int cols = 0; cols < jTable1.getColumnCount(); cols++) {
                        Object valor = jTable1.getValueAt(rows, cols);
                        pdfTable.addCell(valor != null ? valor.toString() : "");
                    }
                }

                doc.add(pdfTable);
                doc.close();
                JOptionPane.showMessageDialog(this, "Reporte PDF guardado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al crear el PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void btnImprimirDirectoActionPerformed(java.awt.event.ActionEvent evt) {
        if (jTable1.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay datos en la tabla para imprimir.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            java.text.MessageFormat header = new java.text.MessageFormat("Reporte del Sistema - SmartRail");
            java.text.MessageFormat footer = new java.text.MessageFormat("Página {0}");

            boolean completado = jTable1.print(
                    JTable.PrintMode.FIT_WIDTH, 
                    header, 
                    footer, 
                    true,  
                    null, 
                    true   
            );

            if (completado) {
                JOptionPane.showMessageDialog(this, "Impresión enviada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "La impresión fue cancelada por el usuario.", "Cancelado", JOptionPane.WARNING_MESSAGE);
            }

        } catch (java.awt.print.PrinterException ex) {
            JOptionPane.showMessageDialog(this, "Error de impresión: " + ex.getMessage(), "Error Crítico", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarReporteReservas() {
        String[] columnas = { "ID", "Usuario", "Tren", "Fecha", "Estado", "Monto" };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        ReservaControlador controlR = new ReservaControlador();
        for (Reserva r : controlR.listarReservas()) {
            modelo.addRow(new Object[] { r.getId(), r.getUsername(), r.getTren(), r.getFecha(), r.getEstado(), r.getMonto() });
        }
        jTable1.setModel(modelo);
    }

    private void cargarReporteTrenes() {
        String[] columnas = { "Código", "Ruta", "Capacidad", "Estado" };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        TrenControlador controlT = new TrenControlador();
        for (Tren t : controlT.listarTrenes()) {
            modelo.addRow(new Object[] { t.getCodigo(), t.getRuta(), t.getCapacidad(), t.isActivo() ? "Activo" : "Inactivo" });
        }
        jTable1.setModel(modelo);
    }

    private void cargarReporteUsuarios() {
        String[] columnas = { "Nombre", "Usuario", "Rol", "Estado" };
        DefaultTableModel modelo = new DefaultTableModel(null, columnas);
        UsuarioControlador usuarioControl = new UsuarioControlador();
        for (Usuario u : usuarioControl.listarUsuarios()) {
            modelo.addRow(new Object[] { u.getNombre(), u.getUsername(), u.getRol(), u.isActivo() ? "Activo" : "Bloqueado" });
        }
        jTable1.setModel(modelo);
    }
}