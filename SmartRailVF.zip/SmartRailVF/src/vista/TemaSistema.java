package vista;

import javax.swing.*;
import java.awt.*;

public final class TemaSistema {
    
    // Paleta de colores mejorada (Material Design)
    private static final Color FONDO = new Color(244, 246, 249);
    private static final Color FONDO_CARD = Color.WHITE;
    private static final Color TEXTO = new Color(33, 37, 41);
    private static final Color TEXTO_SECUNDARIO = new Color(108, 117, 125);
    private static final Color PRIMARIO = new Color(41, 128, 185);
    private static final Color PRIMARIO_HOVER = new Color(31, 97, 141);
    private static final int PADDING = 20;
    private static final String FUENTE = "Segoe UI";

    private TemaSistema() {}

    public static void aplicar() {
        Font fuenteBase = new Font(FUENTE, Font.PLAIN, 14);
        Font fuenteBotones = new Font(FUENTE, Font.BOLD, 14);
        
        UIManager.put("Label.font", fuenteBase);
        UIManager.put("Button.font", fuenteBotones);
        UIManager.put("TextField.font", fuenteBase);
        UIManager.put("PasswordField.font", fuenteBase);
        UIManager.put("ComboBox.font", fuenteBase);
        UIManager.put("Table.font", fuenteBase);
        
        UIManager.put("Panel.background", FONDO);
        UIManager.put("Label.foreground", TEXTO);
        UIManager.put("TextField.background", FONDO_CARD);
        UIManager.put("TextField.foreground", TEXTO);
        
        UIManager.put("TextField.border", BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        UIManager.put("PasswordField.border", UIManager.get("TextField.border"));
                
        UIManager.put("Button.background", PRIMARIO);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.border", BorderFactory.createEmptyBorder(10, 18, 10, 18));
        UIManager.put("Button.focus", PRIMARIO_HOVER);
        
        UIManager.put("Table.background", FONDO_CARD);
        UIManager.put("Table.foreground", TEXTO);
        UIManager.put("Table.gridColor", new Color(230, 230, 230));
        UIManager.put("Table.selectionBackground", new Color(227, 242, 253));
        UIManager.put("Table.selectionForeground", TEXTO);
        UIManager.put("ScrollPane.background", FONDO);
        UIManager.put("ScrollPane.border", BorderFactory.createEmptyBorder());
    }

    public static Color getFondo() { return FONDO; }
    public static Color getFondoCard() { return FONDO_CARD; }
    public static Color getTexto() { return TEXTO; }
    public static Color getTextoSecundario() { return TEXTO_SECUNDARIO; }
    public static Color getPrimario() { return PRIMARIO; }
    public static int getPadding() { return PADDING; }
}